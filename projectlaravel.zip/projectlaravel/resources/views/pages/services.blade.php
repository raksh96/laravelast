@extends('layouts.app')
   
   @section('content')
        <h1>Welcome</h1>
        <p>This is the service page</p>
    </body>
 @endsection