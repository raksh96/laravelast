@extends('layouts.app')
   
   @section('content')
        <h1>Welcome</h1>
        <p>This is the about page</p>
    </body>
 @endsection