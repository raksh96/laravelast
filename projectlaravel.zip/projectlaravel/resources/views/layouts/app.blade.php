<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="{{asset('css/store.php')}}">
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

        <title>{{config('app.name','TestProject')}}</title>

        <!-- Fonts -->
      
    </head>
   
    <body>
     @include('inc.navbar')
      <div class="container">
          @yield('content')
      </div>
    </body>
</html>
